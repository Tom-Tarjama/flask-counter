from flask import Flask, redirect, render_template, session, request

counter = Flask(__name__)
counter.secret_key= "ThisIsSecret"
counter.visits =0
print counter.visits

@counter.route('/')
def index():
	counter.visits+=1
	session['visits'] = counter.visits
	print counter.visits
	# print session['visits']
	return render_template("index.html")

@counter.route('/plusTwo', methods=['POST'])
def plusTwo():
	counter.visits+=1
	session['visits'] = counter.visits
	return redirect('/')

@counter.route('/reset', methods=['POST'])
def reset():
	counter.visits=0
	session['visits'] = counter.visits
	return redirect('/')

counter.run(debug=True)